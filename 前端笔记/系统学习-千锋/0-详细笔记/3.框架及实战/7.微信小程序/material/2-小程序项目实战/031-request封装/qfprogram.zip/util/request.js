function request(params){
  //显示loading
  return new Promise((resolve,reject)=>{
    wx.showLoading({
      title: '正在加载中',
    })
     wx.request({
       ...params,
       url: 'http://localhost:5001'+params.url,
       success:(res)=>{
         resolve(res.data)
       },
       fail:(err)=>{
         reject(err)
       },
       complete:()=>{
         //隐藏loading

         wx.hideLoading({
           success: (res) => {},
         })
       }
     })
  })
}

export default request